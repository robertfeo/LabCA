/*  Header for ticker module

    Computerarchitektur 3
    (C) 2018 J. Friedrich, W. Zimmermann Hochschule Esslingen

    Author:   W.Zimmermann, Jun  10, 2016
    Modified: -

*/

// Public functions, for details see ticker.asm
void initTicker(void);
